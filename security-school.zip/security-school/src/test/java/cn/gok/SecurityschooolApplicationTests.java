package cn.gok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityschooolApplicationTests {

    @Test
    void contextLoads() {
    }

}
